<?php

echo '<h1>Personnel has been successfully assigned</h1?';
$to      = 'nare16229.it@rmkec.ac.in';
$subject = 'Your Assignment';
$message = 'Move to: \n\n https://www.google.com/maps/search/?api=1&query='.$_POST["lat"].','.$_POST["lon"];
$headers = 'From: nareshbabu1136619@gmail.com' . "\r\n" .
    'Reply-To: nareshbabu1136619@gmail.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);
?> 

